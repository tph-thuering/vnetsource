#!/bin/bash
#PBS -q batch
#PBS -N 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000
#PBS -V
#PBS -S /bin/bash
#PBS -p 807
#PBS -l nodes=1:ppn=31
#PBS -d /scratch/pbs_jobs/1379438435.488727_depasse_135_376/1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000

ln -s /home/depasse/openmalaria-dependencies/scenario_30_3.xsd scenario_30_3.xsd
ln -s /home/depasse/openmalaria-dependencies/densities.csv densities.csv
ReturnCode=()
echo 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000.0
/home/depasse/openmalaria-dependencies/openMalaria.30 -s 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000.0.xml --output 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000.0.output --ctsout 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000.0.ctsout
ReturnCode=("${ReturnCode[@]}" $?)
echo "${ReturnCode[@]}" > 1379438435.488727_depasse_135_376__LLIN-Coverage70_EIR-030_IRS-Conservative03_ModelVariants-000.return-codes
NumericReturnCode=$(printf "%s" "${ReturnCode[@]}")
exit `echo "$NumericReturnCode != 0" | bc`
